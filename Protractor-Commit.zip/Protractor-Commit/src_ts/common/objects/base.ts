import { element, browser, by } from "protractor";
import { IBaseClass } from "../interfaces/base.interface";
import { LoginPage } from "../elements/base-elements/base.elements";

export class BaseClass implements IBaseClass{

    async getUrl(): Promise<void> {
        await browser.get('https://qa.clariti.net/login');
    };

    async getLoginCredential(): Promise<void> {
        await element(by.name(LoginPage.EmailField)).sendKeys();
        await element(by.name(LoginPage.PasswordField)).sendKeys();
        await element(by.name(LoginPage.LoginButton)).click();
    };

    async navigateToPage(mainSideBar: string, subSideBar: string): Promise<void> {
        await element(by.name(mainSideBar)).click();
        await element(by.name(subSideBar)).click();
    };

    async tearDown(): Promise<void>  {
        await browser.quit();
    };

};
