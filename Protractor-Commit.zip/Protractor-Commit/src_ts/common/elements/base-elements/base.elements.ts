
export enum LoginPage {
    EmailField       = "login-userName-textbox",
    PasswordField    = "login-password-textbox",
    LoginButton      = "login-ok-button",
}