import {Config, browser} from 'protractor';
import * as reporter from "cucumber-html-reporter";

// An example configuration file
export let config: Config = {

    // set to "custom" instead of cucumber.
    // - framework: 'custom',
    framework: 'jasmine',

    // The address of a running selenium serve selenium addressr.
    directConnect: true,

    // path relative to the current config file
    // - frameworkPath: require.resolve('protractor-cucumber-framework'),

    // Capabilities to be passed to the webdriver instance.
    capabilities: {
      browserName: 'chrome'
    }, 

    // maximize the windows browser
    onPrepare: async () => {

      browser.ignoreSynchronization = true;
      await browser.manage().window().maximize();
    },

    /*
      Spec patterns are relative to the configuration file location passed
      to protractor (in this example conf.js).
      They may include glob patterns.
    */
    specs: ['../../testsuites/sprint1/login-page.suites.js'],

    // Options to be passed to Jasmine-node.
  jasmineNodeOpts: {
    showColors: true, // Use colors in the command line report.
    defaultTimeoutInterval: 30000
  }
    
    /* 
    cucumberOpts: {
      tags: [
        "@SuccessfullLoginTest",
      ],
      format:'json:./reports/cucumber-report.json',
      // require step definitions
      require: [
        './node_modules/protractor-cucumber-steps/index.js',
        '../../testsuite/step_definations/*.js' // accepts a global
      ],
      strict: true,
      dryRun: false,
      compiler: []
    },
    
    onComplete: () => {
      var options = {
        theme: 'bootstrap',
        jsonFile: './reports/cucumber-report.json',
        output: './reports/cucumber-report.html',
        reportSuiteAsScenarios: true,
        launchReport: true,
        metadata: {
            "App Version":"0.3.2",
            "Test Environment": "STAGING",
            "Browser": "Chrome  54.0.2840.98",
            "Platform": "Windows 10",
            "Parallel": "Scenarios",
            "Executed": "Remote"
        }
    };
      reporter.generate(options);
    } 
    
    */
  };