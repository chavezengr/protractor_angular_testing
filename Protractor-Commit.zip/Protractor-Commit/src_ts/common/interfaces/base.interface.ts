export interface IBaseClass{

    /**
       Before executing all test case
    */
    getUrl(): Promise<void>
   
    /**
        Login to this credential
    */
   getLoginCredential(): Promise<void>

    /**
       Navigate to pages
    */
    navigateToPage(mainSideBar: string, subSideBar: string): Promise<void>

    /**
       After fininshing all test case
    */
    tearDown(): Promise<void> 

}