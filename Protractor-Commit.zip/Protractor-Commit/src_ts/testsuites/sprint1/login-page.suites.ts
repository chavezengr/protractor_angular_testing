import { BaseClass } from "../../common/objects/base";
import { delay } from "q";
import { IBaseClass } from "../../common/interfaces/base.interface";

describe('Login Page', () => {

    let util: IBaseClass = new BaseClass;

    beforeEach(async () => {
        util.getUrl();
        precondition();
    });

   async function precondition(): Promise<void>{
        await delay(600000);
        util.getLoginCredential();
   }

    it('Test case - 00001',async () => {



    });

    
    it('Test case - 00002',async () => {
        


    });

    afterEach(async () => {
        util.tearDown();
    });

});

