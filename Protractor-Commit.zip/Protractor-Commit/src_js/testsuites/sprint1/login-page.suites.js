"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const base_1 = require("../../common/objects/base");
const q_1 = require("q");
describe('Login Page', () => {
    let util = new base_1.BaseClass;
    beforeEach(() => __awaiter(void 0, void 0, void 0, function* () {
        util.getUrl();
        precondition();
    }));
    function precondition() {
        return __awaiter(this, void 0, void 0, function* () {
            yield q_1.delay(600000);
            util.getLoginCredential();
        });
    }
    it('Test case - 00001', () => __awaiter(void 0, void 0, void 0, function* () {
    }));
    it('Test case - 00002', () => __awaiter(void 0, void 0, void 0, function* () {
    }));
    afterEach(() => __awaiter(void 0, void 0, void 0, function* () {
        util.tearDown();
    }));
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibG9naW4tcGFnZS5zdWl0ZXMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi9zcmNfdHMvdGVzdHN1aXRlcy9zcHJpbnQxL2xvZ2luLXBhZ2Uuc3VpdGVzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7O0FBQUEsb0RBQXNEO0FBQ3RELHlCQUEwQjtBQUcxQixRQUFRLENBQUMsWUFBWSxFQUFFLEdBQUcsRUFBRTtJQUV4QixJQUFJLElBQUksR0FBZSxJQUFJLGdCQUFTLENBQUM7SUFFckMsVUFBVSxDQUFDLEdBQVMsRUFBRTtRQUNsQixJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7UUFDZCxZQUFZLEVBQUUsQ0FBQztJQUNuQixDQUFDLENBQUEsQ0FBQyxDQUFDO0lBRUosU0FBZSxZQUFZOztZQUN0QixNQUFNLFNBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUNwQixJQUFJLENBQUMsa0JBQWtCLEVBQUUsQ0FBQztRQUMvQixDQUFDO0tBQUE7SUFFQSxFQUFFLENBQUMsbUJBQW1CLEVBQUMsR0FBUyxFQUFFO0lBSWxDLENBQUMsQ0FBQSxDQUFDLENBQUM7SUFHSCxFQUFFLENBQUMsbUJBQW1CLEVBQUMsR0FBUyxFQUFFO0lBSWxDLENBQUMsQ0FBQSxDQUFDLENBQUM7SUFFSCxTQUFTLENBQUMsR0FBUyxFQUFFO1FBQ2pCLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztJQUNwQixDQUFDLENBQUEsQ0FBQyxDQUFDO0FBRVAsQ0FBQyxDQUFDLENBQUMifQ==