"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const protractor_1 = require("protractor");
const base_elements_1 = require("../elements/base-elements/base.elements");
class BaseClass {
    getUrl() {
        return __awaiter(this, void 0, void 0, function* () {
            yield protractor_1.browser.get('https://qa.clariti.net/login');
        });
    }
    ;
    getLoginCredential() {
        return __awaiter(this, void 0, void 0, function* () {
            yield protractor_1.element(protractor_1.by.name(base_elements_1.LoginPage.EmailField)).sendKeys();
            yield protractor_1.element(protractor_1.by.name(base_elements_1.LoginPage.PasswordField)).sendKeys();
            yield protractor_1.element(protractor_1.by.name(base_elements_1.LoginPage.LoginButton)).click();
        });
    }
    ;
    navigateToPage(mainSideBar, subSideBar) {
        return __awaiter(this, void 0, void 0, function* () {
            yield protractor_1.element(protractor_1.by.name(mainSideBar)).click();
            yield protractor_1.element(protractor_1.by.name(subSideBar)).click();
        });
    }
    ;
    tearDown() {
        return __awaiter(this, void 0, void 0, function* () {
            yield protractor_1.browser.close();
        });
    }
    ;
}
exports.BaseClass = BaseClass;
;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYmFzZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uL3NyY190cy9jb21tb24vb2JqZWN0cy9iYXNlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7O0FBQUEsMkNBQWtEO0FBRWxELDJFQUFvRTtBQUVwRSxNQUFhLFNBQVM7SUFFWixNQUFNOztZQUNSLE1BQU0sb0JBQU8sQ0FBQyxHQUFHLENBQUMsOEJBQThCLENBQUMsQ0FBQztRQUN0RCxDQUFDO0tBQUE7SUFBQSxDQUFDO0lBRUksa0JBQWtCOztZQUNwQixNQUFNLG9CQUFPLENBQUMsZUFBRSxDQUFDLElBQUksQ0FBQyx5QkFBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsUUFBUSxFQUFFLENBQUM7WUFDeEQsTUFBTSxvQkFBTyxDQUFDLGVBQUUsQ0FBQyxJQUFJLENBQUMseUJBQVMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLFFBQVEsRUFBRSxDQUFDO1lBQzNELE1BQU0sb0JBQU8sQ0FBQyxlQUFFLENBQUMsSUFBSSxDQUFDLHlCQUFTLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxLQUFLLEVBQUUsQ0FBQztRQUMxRCxDQUFDO0tBQUE7SUFBQSxDQUFDO0lBRUksY0FBYyxDQUFDLFdBQW1CLEVBQUUsVUFBa0I7O1lBQ3hELE1BQU0sb0JBQU8sQ0FBQyxlQUFFLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsS0FBSyxFQUFFLENBQUM7WUFDNUMsTUFBTSxvQkFBTyxDQUFDLGVBQUUsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxLQUFLLEVBQUUsQ0FBQztRQUMvQyxDQUFDO0tBQUE7SUFBQSxDQUFDO0lBRUksUUFBUTs7WUFDVixNQUFNLG9CQUFPLENBQUMsS0FBSyxFQUFFLENBQUM7UUFDMUIsQ0FBQztLQUFBO0lBQUEsQ0FBQztDQUVMO0FBckJELDhCQXFCQztBQUFBLENBQUMifQ==