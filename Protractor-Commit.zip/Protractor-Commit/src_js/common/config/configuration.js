"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const protractor_1 = require("protractor");
// An example configuration file
exports.config = {
    // set to "custom" instead of cucumber.
    // - framework: 'custom',
    framework: 'jasmine',
    // The address of a running selenium serve selenium addressr.
    directConnect: true,
    // path relative to the current config file
    // - frameworkPath: require.resolve('protractor-cucumber-framework'),
    // Capabilities to be passed to the webdriver instance.
    capabilities: {
        browserName: 'chrome'
    },
    // maximize the windows browser
    onPrepare: () => __awaiter(void 0, void 0, void 0, function* () {
        protractor_1.browser.ignoreSynchronization = true;
        yield protractor_1.browser.manage().window().maximize();
    }),
    /*
      Spec patterns are relative to the configuration file location passed
      to protractor (in this example conf.js).
      They may include glob patterns.
    */
    specs: ['../../testsuites/sprint1/login-page.suites.js'],
    // Options to be passed to Jasmine-node.
    jasmineNodeOpts: {
        showColors: true,
        defaultTimeoutInterval: 30000
    }
    /*
    cucumberOpts: {
      tags: [
        "@SuccessfullLoginTest",
      ],
      format:'json:./reports/cucumber-report.json',
      // require step definitions
      require: [
        './node_modules/protractor-cucumber-steps/index.js',
        '../../testsuite/step_definations/*.js' // accepts a global
      ],
      strict: true,
      dryRun: false,
      compiler: []
    },
    
    onComplete: () => {
      var options = {
        theme: 'bootstrap',
        jsonFile: './reports/cucumber-report.json',
        output: './reports/cucumber-report.html',
        reportSuiteAsScenarios: true,
        launchReport: true,
        metadata: {
            "App Version":"0.3.2",
            "Test Environment": "STAGING",
            "Browser": "Chrome  54.0.2840.98",
            "Platform": "Windows 10",
            "Parallel": "Scenarios",
            "Executed": "Remote"
        }
    };
      reporter.generate(options);
    }
    
    */
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29uZmlndXJhdGlvbi5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uL3NyY190cy9jb21tb24vY29uZmlnL2NvbmZpZ3VyYXRpb24udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7QUFBQSwyQ0FBMkM7QUFHM0MsZ0NBQWdDO0FBQ3JCLFFBQUEsTUFBTSxHQUFXO0lBRXhCLHVDQUF1QztJQUN2Qyx5QkFBeUI7SUFDekIsU0FBUyxFQUFFLFNBQVM7SUFFcEIsNkRBQTZEO0lBQzdELGFBQWEsRUFBRSxJQUFJO0lBRW5CLDJDQUEyQztJQUMzQyxxRUFBcUU7SUFFckUsdURBQXVEO0lBQ3ZELFlBQVksRUFBRTtRQUNaLFdBQVcsRUFBRSxRQUFRO0tBQ3RCO0lBRUQsK0JBQStCO0lBQy9CLFNBQVMsRUFBRSxHQUFTLEVBQUU7UUFFcEIsb0JBQU8sQ0FBQyxxQkFBcUIsR0FBRyxJQUFJLENBQUM7UUFDckMsTUFBTSxvQkFBTyxDQUFDLE1BQU0sRUFBRSxDQUFDLE1BQU0sRUFBRSxDQUFDLFFBQVEsRUFBRSxDQUFDO0lBQzdDLENBQUMsQ0FBQTtJQUVEOzs7O01BSUU7SUFDRixLQUFLLEVBQUUsQ0FBQywrQ0FBK0MsQ0FBQztJQUV4RCx3Q0FBd0M7SUFDMUMsZUFBZSxFQUFFO1FBQ2YsVUFBVSxFQUFFLElBQUk7UUFDaEIsc0JBQXNCLEVBQUUsS0FBSztLQUM5QjtJQUVDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztNQW1DRTtDQUNILENBQUMifQ==