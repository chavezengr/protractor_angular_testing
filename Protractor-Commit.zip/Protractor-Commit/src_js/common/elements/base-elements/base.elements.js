"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var LoginPage;
(function (LoginPage) {
    LoginPage["EmailField"] = "login-userName-textbox";
    LoginPage["PasswordField"] = "login-password-textbox";
    LoginPage["LoginButton"] = "login-ok-button";
})(LoginPage = exports.LoginPage || (exports.LoginPage = {}));
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYmFzZS5lbGVtZW50cy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NyY190cy9jb21tb24vZWxlbWVudHMvYmFzZS1lbGVtZW50cy9iYXNlLmVsZW1lbnRzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQ0EsSUFBWSxTQUlYO0FBSkQsV0FBWSxTQUFTO0lBQ2pCLGtEQUEyQyxDQUFBO0lBQzNDLHFEQUEyQyxDQUFBO0lBQzNDLDRDQUFvQyxDQUFBO0FBQ3hDLENBQUMsRUFKVyxTQUFTLEdBQVQsaUJBQVMsS0FBVCxpQkFBUyxRQUlwQiJ9